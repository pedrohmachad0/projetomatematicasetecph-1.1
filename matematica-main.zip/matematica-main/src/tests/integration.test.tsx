import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import App from '../App'

beforeEach(() => {
  localStorage.clear()
  vi.spyOn(window, 'scrollTo').mockImplementation(() => {})
})

afterEach(() => {
  cleanup()
  vi.restoreAllMocks()
})

describe('Navegação do projeto unificado', () => {
  it('abre o RPG, inicia uma batalha e oferece acesso aos quizzes', () => {
    window.history.replaceState({}, '', '/aprender')
    render(<App />)
    expect(screen.getByRole('link', { name: 'Quizzes' })).toHaveAttribute('href', '/praticar')
    fireEvent.click(screen.getByRole('button', { name: /Começar aventura/ }))
    expect(screen.getByRole('button', { name: /Confirmar/ })).toBeInTheDocument()
  })

  it('abre a biblioteca de quizzes e navega para o quiz de frações', () => {
    window.history.replaceState({}, '', '/praticar')
    render(<App />)
    expect(screen.getByRole('heading', { name: 'Escolha um tema para praticar' })).toBeInTheDocument()
    const link = screen.getAllByRole('link', { name: /Começar quiz/ }).find(
      (element) => element.getAttribute('href') === '/quiz/fracoes',
    )!
    fireEvent.click(link)
    expect(screen.getByRole('heading', { name: 'Quiz de Frações' })).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: /Começar quiz/ }))
    expect(screen.getByRole('progressbar', { name: 'Progresso do quiz' })).toBeInTheDocument()
  })

  it('mantém o atalho de frações para o quiz e o retorno ao RPG', () => {
    window.history.replaceState({}, '', '/fracoes')
    render(<App />)
    expect(screen.getByRole('link', { name: /Praticar com quiz de frações/ })).toHaveAttribute('href', '/quiz/fracoes')
    fireEvent.click(screen.getByRole('link', { name: /Voltar para aprender/ }))
    expect(screen.getByRole('button', { name: /Começar aventura/ })).toBeInTheDocument()
  })
})
