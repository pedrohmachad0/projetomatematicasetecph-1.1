# Plataforma de Simuladores Matemáticos Interativos — PEMFM

## Projeto unificado

Esta pasta reúne os cinco simuladores, a aventura RPG MathQuest (`/aprender`) e a trilha com quizzes por assunto (`/praticar` e `/quiz/:topic`). Consulte [INTEGRACAO.md](INTEGRACAO.md) para a identificação das versões e o mapa da integração.

Plataforma web educacional com Hub, cinco simuladores interativos, aventura RPG e quizzes, desenvolvida em **React + TypeScript + Vite + Tailwind + SVG + Framer Motion**.

**Stack:** React 19, Vite 8, TypeScript 6, Tailwind 4, Framer Motion 13, Lucide React, Vitest + Testing Library, Oxlint/Prettier.

## Simuladores

1. **Explorador de Pitágoras** (`/pitagoras`) — ângulo 10°–120° passo 10°, dois lados fixos de 10u, terceiro lado via Lei dos Cossenos, 3 quadrados (2 fixos + 1 dinâmico), classificação acutângulo/retângulo/obtusângulo com cor + texto, comparação `A²+B² <> C²`.
2. **Cálculo Mental — Soma** (`/soma`) — 10 problemas em `src/data/additionProblems.ts`, material dourado (barras dezenas + cubos unidades), transferência mantém soma constante, destaque dezena exata, animação.
3. **Cálculo Mental — Subtração** (`/subtracao`) — 10 problemas em `src/data/subtractionProblems.ts`, reta numérica SVG com marcações, deslocamento `-1/+1` mantém diferença, posição original tracejada, destaque dezena.
4. **Explorador de Frações** (`/fracoes`) — partes do inteiro, decimal, porcentagem e simplificação, com atalho para o quiz de frações.
5. **Explorador de Porcentagem** (`/porcentagem`) — representação visual de proporções, descontos e acréscimos.

Todos com SVG, Tailwind, acessibilidade (`aria-label`, foco visível, teclado), responsivo mobile/desktop/projetor/TV sem overflow.

## Rodar local

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # tsc -b && vite build
npm run test     # vitest run
npm run lint     # oxlint
```

## Publicação na Vercel

No plano Hobby, se o repositório for privado, o autor do commit precisa ser a conta proprietária do projeto na Vercel (`mestrenaranked`). Commits de outra conta podem chegar ao GitHub, mas ter o deploy bloqueado.



## Estrutura

```
src/
├── components/{pitagoras,soma,subtracao}/
├── pages/{Hub,Pitagoras,CalcSoma,CalcSubtracao}
├── data/{additionProblems,subtractionProblems,mathContent}
├── logic/{pitagoras,adicao,subtracao,calculoMental}
└── tests/
```

Arquitetura preparada para expansão Fundamental II (6º–9º) e Médio (1º–3º) via `src/data/mathContent.ts`.

---

> Template base Vite + React. Ver `regrasdoprojeto.md` para regras técnicas e pedagógicas.
