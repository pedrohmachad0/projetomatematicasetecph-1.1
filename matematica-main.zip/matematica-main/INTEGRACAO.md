# Integração dos projetos

## Identificação das versões

- `matematica-main`: versão com MathQuest em `/aprender`, dez fases, batalhas, vidas, XP, chefe final, inventário e fonte pixel local.
- `projetomatematicasetecph-1.1-main`: versão com trilha de aprendizagem e biblioteca de quizzes específicos dos cinco simuladores.

A comparação dos arquivos mostrou que os simuladores de Pitágoras, Soma, Subtração e Porcentagem, seus componentes e a lógica matemática são idênticos nas duas pastas. Frações também possui a mesma simulação; somente os links de prática são diferentes.

## Projeto consolidado

`matematica-unificado` utiliza a estrutura e o tema do projeto MathQuest e incorpora as funcionalidades complementares da outra versão:

| Rota | Conteúdo |
| --- | --- |
| `/` | Catálogo dos cinco simuladores |
| `/pitagoras`, `/soma`, `/subtracao`, `/fracoes`, `/porcentagem` | Simuladores originais completos |
| `/aprender` | Aventura RPG MathQuest |
| `/praticar` | Trilha original e biblioteca de quizzes por assunto |
| `/quiz/:topic` | Quiz do assunto escolhido |

Os assuntos válidos são `pitagoras`, `soma`, `subtracao`, `fracoes` e `porcentagem`. A navegação possui acesso ao RPG e aos quizzes. Frações mantém o atalho para seu quiz. Os testes das duas versões foram reunidos.

As duas pastas de origem foram preservadas. Não foi adicionado backend nem novas bibliotecas. Os sistemas mantêm suas próprias chaves de progresso no armazenamento do navegador; XP e inventário pertencem à aventura RPG. Para manter um progresso já existente, é necessário usar a mesma origem (protocolo, endereço e porta) no navegador.

## Execução

Abra um terminal em `matematica-unificado` e execute:

```powershell
npm ci
npm run dev
```

Para validar:

```powershell
npm run test
npm run lint
npm run build
```

## Validação realizada

- 79 testes aprovados em 7 arquivos, incluindo navegação entre RPG, biblioteca de quizzes e Frações.
- Compilação de produção aprovada.
- Lint aprovado, com dois avisos preexistentes de Fast Refresh no inventário.
- No navegador: catálogo dos cinco simuladores, início de batalha RPG e correção de resposta, acesso à biblioteca, início de quiz de Frações e correção de resposta, alteração de `1/4` para `2/4`, cálculo de `0,5`, `50%` e simplificação para `1/2`.
- Console sem erros nas interações verificadas.

O build avisa que o pacote JavaScript ultrapassa 500 kB após a união. Isso não impede a compilação ou execução.
